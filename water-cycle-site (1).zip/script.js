
function showInfo(stage) {
    const infoBox = document.getElementById("info-box");
    let info = "";
    switch (stage) {
        case "evaporation":
            info = "Evaporation is when water changes from a liquid to a gas due to heat.";
            break;
        case "condensation":
            info = "Condensation is when water vapor cools down and changes back into liquid droplets.";
            break;
        case "precipitation":
            info = "Precipitation is when water falls from the sky as rain, snow, sleet, or hail.";
            break;
        case "collection":
            info = "Collection is when the fallen water gathers in oceans, lakes, and rivers.";
            break;
    }
    infoBox.innerHTML = "<p>" + info + "</p>";
}
